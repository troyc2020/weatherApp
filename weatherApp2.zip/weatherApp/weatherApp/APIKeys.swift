//
//  APIKeys.swift
//  weatherApp
//
//  Created by Troy Cavanagh on 25/4/20.
//  Copyright © 2020 Troy Cavanagh. All rights reserved.
//

import Foundation

struct APIkeys {
    static let darkSkyKey = "8f386baa93d641744dd06329e0592494"
}

struct APIurls {
    static let darkSkyURL = "https://api.darksky.net/forecast/"
}
